import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.preprocessing import LabelEncoder
import os

SAVE_DIR = "models/visualizations"
os.makedirs(SAVE_DIR, exist_ok=True)

print("\n📥 Loading feature data...")
X_test = np.load("models/X_test.npy")
y_test = np.load("models/y_test.npy", allow_pickle=True)

encoder = LabelEncoder()
encoder.classes_ = np.load("models/label_classes.npy", allow_pickle=True)
y_int = encoder.transform(y_test)

class_names = encoder.classes_
unique_classes = np.unique(y_int)

print("\n🔍 Dataset shapes:")
print(f"X_test: {X_test.shape}, y_test: {y_test.shape}")
print(f"Classes: {list(class_names)}")


# ---------------------- Helper: Plotting Function ----------------------
def plot_embedding(embedding, title, filename, y_labels, classes, is_filtered=False):
    plt.figure(figsize=(12, 8))
    
    for cls in np.unique(y_labels):
        idx = np.where(y_labels == cls)[0]
        plt.scatter(embedding[idx, 0], embedding[idx, 1], s=18, alpha=0.6, label=classes[cls])

    plt.title(title)
    plt.legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=7)
    plt.tight_layout()
    plt.savefig(os.path.join(SAVE_DIR, filename))
    plt.show()

    tag = "FILTERED" if is_filtered else "FULL"
    print(f"📁 Saved {tag} visualization → {filename}")


# ---------------------- STEP 1: Flatten Features ----------------------
X_flat = X_test.reshape(X_test.shape[0], -1)


# ============================================================
# 1️⃣ PCA (FULL DATA + SILENCE)
# ============================================================
print("\n🎨 Running PCA (full dataset)...")
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_flat)

plot_embedding(
    X_pca,
    "PCA Clustering of Bark Audio Features — Full Dataset",
    "pca_full.png",
    y_int,
    class_names
)


# ============================================================
# 2️⃣ TSNE (FULL DATA)
# ============================================================
print("\n🌀 Running t-SNE (May take time)...")
tsne = TSNE(n_components=2, perplexity=30, learning_rate=200)
X_tsne = tsne.fit_transform(X_flat)

plot_embedding(
    X_tsne,
    "t-SNE Clustering of Bark Audio Features — Full Dataset",
    "tsne_full.png",
    y_int,
    class_names
)


# ============================================================
# 🔥 FILTER OUT SILENCE CLASS (‘S’)
# ============================================================
print("\n✂ Filtering out silence class 'S'...")

silence_index = np.where(class_names == "S")[0][0]
mask = y_int != silence_index

X_filtered = X_flat[mask]
y_filtered = y_int[mask]

print(f"Remaining samples: {len(y_filtered)} (removed {len(y_int)-len(y_filtered)} silence samples)")


# ---------------------- PCA WITHOUT SILENCE ----------------------
print("\n🎨 Running PCA (without silence)...")
pca_clean = PCA(n_components=2)
X_pca_clean = pca_clean.fit_transform(X_filtered)

plot_embedding(
    X_pca_clean,
    "PCA Clustering — Without Silence Class",
    "pca_no_silence.png",
    y_filtered,
    class_names,
    is_filtered=True
)


# ---------------------- TSNE WITHOUT SILENCE ----------------------
print("\n🌀 Running t-SNE (without silence)...")
tsne_clean = TSNE(n_components=2, perplexity=30, learning_rate=200)
X_tsne_clean = tsne_clean.fit_transform(X_filtered)

plot_embedding(
    X_tsne_clean,
    "t-SNE Clustering — Without Silence Class",
    "tsne_no_silence.png",
    y_filtered,
    class_names,
    is_filtered=True
)

print("\n🎉 Visualizations complete!")
print(f"📂 All plots saved inside: {SAVE_DIR}")
